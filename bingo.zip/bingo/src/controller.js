var chkreload=false
var json

